import os

def post_register_types(root_module):
    root_module.add_include('"ns3/network-module.h"')
