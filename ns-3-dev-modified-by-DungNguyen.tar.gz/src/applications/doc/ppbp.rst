.. include:: replace.txt

The Poisson Pareto Burst Process (PPBP)

PPBP architecture
-----------------
The PPBP is a process based on the overlapping of multiple bursts with
heavy-tailed distributed lengths [1], [2].
Events in this process represent points of time at which one of an infinite
population of users begins or stops transmitting a traffic burst.
The PPBP is closely related to the M/G/∞ queue model.

In the PPBP model, bursts arrive according to a Poisson process with rate λp,
and their length follows a Pareto distribution characterized by Hurst parameter
H, typically between 0.5 and 0.9, and a mean Ton. Each burst is modeled by a
flow with a constant bit-rate r. Then, the overlapping bursts form in
aggregate a Long-Range Dependent traffic provided the burst length have
infinite variance.

Summary of parameters
---------------------
λp:	mean rate of burst arrivals
Ton:	mean burst time length
r:	Burst intensity

Based on Little’s law, the average number of active bursts is given by:
E[n] = Ton x λp
Since each burst gives birth to a flow with a constant bit-rate, it is then
straightforward to compute the overall rate of the PPBP, λ: λ = Ton x λp x r

PPBP overview
-------------
The PPBP module allows any NS-3 practitioners to easily generate a single flow
according to the PPBP process. 
A new PPBP source can be introduced within a simulation scenario with just a
couple of lines of code. In practice, the practitioners simply need to setup
the PPBP source by defining values for the Hurst parameter, H, the mean length
of a burst, Ton, the bit-rate of each individual burst, r and the arrival rate
of burst, λp, (or alternately, the average number of active bursts E[n]) so
that, overall, the rate of the PPBP source, λ, gets the desirable value.

An example of the use of the PPBP network traffic generator can be found in
``examples/ppbp/`` directory.

The PPBP module consists of two main functions.
-	The first function allows to keep track of the current number of active
	bursts at time t, nt, taking into account that their arrival process
	follows a Poisson process and that their length is determined by a Pareto
	distribution.
-	The second function generates the packets departure at a constant bit-rate
	nt x r, and thus needs to query the first function.

References
----------
[1]	A new tool for generating realistic Internet traffic in NS-3,
	D. Ammar, T. Begin and I. Guérin Lassous.
	4th International ICST Conference on Simulation Tools and Techniques (SIMUTools),
	Barcelona, Spain, March 21-25, 2011, Poster.
[2]	M. Zukerman, T. D. Neame and R. G. Addie,
	Internet Traffic Modeling and Future Technology Implications.
	Proceedings of INFOCOM 2003, San Francisco, USA, April 2003.

