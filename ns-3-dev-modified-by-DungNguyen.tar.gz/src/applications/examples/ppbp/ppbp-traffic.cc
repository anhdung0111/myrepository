/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2011 Doreid AMMAR
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Doreid Ammar <doreid.ammar@gmail.com>
 */

/*
 * This example experiment provide a simple script to send PPBP traffic over
 * a communication link.
 *
 * To increase confidence the experiment can be run a user-defined number
 * of independent replications.
 *
 * Many of the experiments parameters can be controlled via command
 * line arguments.
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cassert>

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("PPBPTraffic");

/* Network topology
 *
 *              10Mb/s, 10ms
 *    n0 ------------------------- n1
 * (10.1.1.1)                  (10.1.1.2)
 *
 * - Point-to-point links with indicated one-way BW/delay
 * - PPBP traffic from n0 to n1
 *   Poisson Pareto Burst Process (PPBP) of rate λ:
 *	 λ = Ton x λp x r (see details in PPBP-application.h)
 */

class Experiment
{
private:
  double m_simulationTime;       // number of seconds the simulation is to run


public:
  void RunOne (double simulationTime, double burst, uint32_t packetsize, bool enableFlowMonitor, int rep)
  {
    m_simulationTime = simulationTime;

    // Define the number of nodes
    // ns3::PacketMetadata::Enable ();
    uint32_t nnodes = 2;

    // Set up some default values for the simulation.
    Config::SetDefault ("ns3::DropTailQueue::MaxPackets", UintegerValue (83));
    Config::SetDefault ("ns3::PPBPApplication::H", DoubleValue (0.7));

    // Topology
    // Create nodes
    NS_LOG_INFO ("Create nodes.");
    NodeContainer c;
    c.Create (nnodes);
    NodeContainer n0n1 = NodeContainer (c.Get (0), c.Get (1));
    InternetStackHelper internet;
    internet.Install (c);

    // Install point-to-point devices
    // We create the channels first without any IP addressing information
    NS_LOG_INFO ("Create channels.");
    PointToPointHelper p2p;
    p2p.SetDeviceAttribute ("DataRate", StringValue ("10Mbps"));
    p2p.SetChannelAttribute ("Delay", StringValue ("10ms"));
    NetDeviceContainer d0d1 = p2p.Install (n0n1);

    // we attach a queue to the each PointToPointNetDevice
    // Calling NetDeviceContainer::Get (i) will return a Ptr<NetDevice>
    // Node n0
    Ptr<NetDevice> net0 = d0d1.Get (0);

    PointerValue tmp0;
    net0->GetAttribute ("TxQueue", tmp0);
    Ptr<Queue> txQueue0 = tmp0.Get<Queue> ();

    Ptr<DropTailQueue> DropTailQueue0 = DynamicCast<DropTailQueue> (txQueue0);

    // Later, we add IP addresses.
    NS_LOG_INFO ("Assign IP Addresses.");
    Ipv4AddressHelper ipv4;
    ipv4.SetBase ("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer i0i1 = ipv4.Assign (d0d1);

    //ROUTING
    // Create router nodes, initialize routing database and set up the routing
    // tables in the nodes.
    Ipv4GlobalRoutingHelper::PopulateRoutingTables ();

    // Create Application
    // Send PPBP/UDP datagrams from n0 to n1
    NS_LOG_INFO ("Create Applications.");
    uint16_t port = 9;               // Discard port (RFC 863)

    // Install PacketSink on Node 1 (= Sink) receive from all
    PacketSinkHelper sinkApp ("ns3::UdpSocketFactory", Address (InetSocketAddress (Ipv4Address::GetAny (), port)));

    ApplicationContainer app0 = sinkApp.Install (c.Get (1));
    app0.Start (Seconds (0.0));
    app0.Stop (Seconds (m_simulationTime));

    // Install PPBP Application on Node 0 (= Sender)
    PPBPHelper PPBPApp ("ns3::UdpSocketFactory", Address (InetSocketAddress (i0i1.GetAddress (1), port)));
    PPBPApp.SetAttribute ("MeanBurstArrivals", RandomVariableValue (ConstantVariable (burst)));
    PPBPApp.SetAttribute ("MeanBurstTimeLength", RandomVariableValue (ConstantVariable (0.2)));
    PPBPApp.SetAttribute ("BurstIntensity", StringValue ("1Mbps"));
    PPBPApp.SetAttribute ("PacketSize", UintegerValue (packetsize));

    ApplicationContainer app1 = PPBPApp.Install (c.Get (0));
    app1.Start (Seconds (0.0));
    app1.Stop (Seconds (m_simulationTime));

    AsciiTraceHelper ascii;
    Ptr<OutputStreamWrapper> osw = ascii.CreateFileStream ("ppbp-traffic.tr");
    p2p.EnableAsciiAll (osw);

    // Flow Monitor
    Ptr<FlowMonitor> flowmon;
    if (enableFlowMonitor)
      {
        FlowMonitorHelper flowmonHelper;
        flowmon = flowmonHelper.InstallAll ();
        flowmon->SetAttribute ("DelayBinWidth", DoubleValue (0.1));
        flowmon->SetAttribute ("JitterBinWidth", DoubleValue (0.0001));
        flowmon->SetAttribute ("PacketSizeBinWidth", DoubleValue (20));
      }

    NS_LOG_INFO ("Run Simulation.");
    Simulator::Stop (Seconds (m_simulationTime));
    Simulator::Run ();
    NS_LOG_INFO ("Done.");

    // Tracing to file "traceFile_rep"
    std::string traceFiletr;
    std::string traceFileflowmon;

    std::string traceFile ("traceFile_rep");

    std::string srep;
    {
      std::ostringstream oss;
      oss << ++rep;
      srep = oss.str ();
    }
    traceFile.insert (13, srep);
    traceFileflowmon = traceFile + ".xml";

    std::cout << "TRACE FILE: " << traceFileflowmon << std::endl;

    if (enableFlowMonitor)
      {
        flowmon->SerializeToXmlFile (traceFileflowmon, true, true);
      }

    Simulator::Destroy ();
  }
};

// main
int main (int argc, char *argv[])
{
  // Users may find it convenient to turn on explicit debugging
  // for selected modules; the below lines suggest how to do this
  // LogComponentEnable("PPBPTraffic", LOG_LOGIC);
  // LogComponentEnable("PPBPApplication", LOG_LOGIC);
  // LogComponentEnable("PPBPApplication", LOG_LEVEL_ALL);

  bool enableFlowMonitor = true;
  CommandLine cmd;

  int replications = 6;
  double simulationTime = 100;

  cmd.AddValue ("Replications", "Perform independent replications", replications);
  cmd.AddValue ("SimulationTime", "Time to run each simulation", simulationTime);
  cmd.AddValue ("EnableMonitor", "Enable Flow Monitor", enableFlowMonitor);
  cmd.Parse (argc, argv);

  // example
  const double burst[] = { 20 };
  const unsigned int packetSizes[] = { 1470 };

  // const double burst[] = { 10, 20, 30 };
  // const unsigned int packetSizes[] = { 1470, 160, 100, 20 };

  for (unsigned int bursti = 0; bursti < sizeof(burst) / sizeof(burst[0]); ++bursti)
    {
      for (unsigned int psi = 0; psi < sizeof(packetSizes) / sizeof(packetSizes[0]); ++psi)
        {
          // run independent replications with same configuration
          for (int rep = 0; rep < replications; ++rep)
            {
              SeedManager::SetRun (rep);
              std::cout << std::endl << "replication " << rep + 1 << std::endl;

              // run experiment
              Experiment experiment;
              experiment.RunOne (simulationTime, burst[bursti], packetSizes[psi], enableFlowMonitor, rep);
            }
        }
    }
}
