#ifndef UNUSED_H
#define UNUSED_H

#ifndef NS_UNUSED
# define NS_UNUSED(x) ((void)(x))
#endif

#endif /* UNUSED_H */
